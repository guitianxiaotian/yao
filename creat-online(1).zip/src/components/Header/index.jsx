import React from 'react';

import logo from '../../assets/logo.png';
import './Header.css';

function Header() {
  return (
    <header className="header">
      <div className="header-left">
        <img src={logo} width={42} height={42} alt="logo" />
        <h3
          style={{ marginLeft: 12, cursor: 'pointer' }}
          onClick={() => (window.location.href = '/')}
        >
          School management
        </h3>

        <nav className="header-nav">
          <div className="header-nav-item">
            <div onClick={() => (window.location.href = '/home')}>
              Teacher Management
            </div>
          </div>
          <div className="header-nav-item">
            <div onClick={() => (window.location.href = '/teachers')}>
              Our Teachers
            </div>
          </div>
          <div className="header-nav-item">
            <div onClick={() => (window.location.href = '/message-boards')}>
              Message Boards
            </div>
          </div>
        </nav>
      </div>

      <div className="userinfo">
        <p>{localStorage.getItem('username') || 'admin    '}</p>
        <button onClick={() => (window.location.href = '/')}>
          Log out
        </button>
      </div>
    </header>
  );
}

export default Header;
