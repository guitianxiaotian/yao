import { useState } from 'react';
import { useNavigate } from 'react-router';
import validator from 'validator';
import logo from '../assets/school.png';
import './Login.css';

function Login() {
  const [errMsg, setErrMsg] = useState('');

  const [isTeacher, setisTeacher] = useState(false);

  const navigate = useNavigate();

  const [studentNo, setStudentNo] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const toggle = () => {
    // reset
    setEmail('');
    setPassword('');
    setStudentNo('');
    setErrMsg('');
    // toggle
    setisTeacher(!isTeacher);
  };

  const handleLogin = () => {
    setErrMsg('');
    // vidate form
    let _errMsg = [];

    if (isTeacher) {
      if (!validator.isEmail(email)) {
        _errMsg.push(<div>Incorrect email format</div>);
      }
    } else {
      // student
      if (!validator.isLength(studentNo, { min: 5, max: 5 })) {
        _errMsg.push(<div>The length of the studentNo is 5</div>);
      }
    }

    if (!validator.isLength(password, { min: 3, max: 30 })) {
      _errMsg.push(
        <div>The length of the password is between 3-30 characters</div>
      );
    }

    if (_errMsg.length > 0) {
      return setErrMsg(_errMsg);
    }

    localStorage.setItem('username', email || studentNo);
    // submit
    navigate('/home');
  };

  return (
    <div>
      <header className="nav">
        <img src={logo} width={40} height={40} alt="logo" />
        <h3 style={{ marginLeft: 24 }}>School Management</h3>
      </header>
      <div className="form">
        {isTeacher ? (
          <div className="group">
            <div className="label">Email</div>
            <input
              type="email"
              name="email"
              required
              value={email}
              placeholder="Email"
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
        ) : (
          <div className="group">
            <div className="label">Student No</div>
            <input
              type="text"
              name="studentNo"
              required
              value={studentNo}
              placeholder="StudentNo"
              onChange={(e) => setStudentNo(e.target.value)}
            />
          </div>
        )}

        <div className="group">
          <div className="label">Password</div>
          <input
            type="password"
            name="password"
            required
            value={password}
            placeholder="Password"
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <div className="error-msg">{errMsg}</div>

        <div className="group" style={{ textAlign: 'right' }}>
          <button onClick={handleLogin} style={{ height: 40 }}>
            Log In
          </button>
        </div>

        <div className="line"></div>

        {isTeacher ? (
          <div>
            Are you a student?
            <span className="text-link" onClick={toggle}>
              Back To
            </span>
          </div>
        ) : (
          <div>
            <h2>Are you a teacher?</h2>

            <button
              className="default"
              style={{ width: '100%', height: 50 }}
              onClick={toggle}
            >
              Teacher Login
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default Login;
