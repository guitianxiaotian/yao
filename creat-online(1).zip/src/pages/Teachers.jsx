import { useEffect, useState, useCallback } from 'react';
import Header from '../components/Header';
import './Teachers.css';

const mockData = [
  {
    id: '20230001',
    name: 'Tom',
    age: 21,
    academy: 'Academy A',
    like: 0,
    desc: 'Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed erat diam, blandit eget felis aliquam, rhoncus varius urna. Donec tellus sapien, sodales eget ante vitae, feugiat ullamcorper urna. Praesent auctor dui vitae dapibus eleifend. Proin viverra mollis neque, ut ullamcorper elit posuere eget.',
  },
  {
    id: '20230002',
    name: 'James',
    age: 23,
    academy: 'Academy B',
    like: 0,
    desc: 'Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed erat diam, blandit eget felis aliquam, rhoncus varius urna. Donec tellus sapien, sodales eget ante vitae, feugiat ullamcorper urna. Praesent auctor dui vitae dapibus eleifend. Proin viverra mollis neque, ut ullamcorper elit posuere eget.',
  },
  {
    id: '20230003',
    name: 'Jack',
    age: 26,
    academy: 'Academy C',
    like: 0,
    desc: 'Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed erat diam, blandit eget felis aliquam, rhoncus varius urna. Donec tellus sapien, sodales eget ante vitae, feugiat ullamcorper urna. Praesent auctor dui vitae dapibus eleifend. Proin viverra mollis neque, ut ullamcorper elit posuere eget.',
  },
  {
    id: '20230004',
    name: 'Ali',
    age: 28,
    academy: 'Academy C',
    like: 0,
    desc: 'Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed erat diam, blandit eget felis aliquam, rhoncus varius urna. Donec tellus sapien, sodales eget ante vitae, feugiat ullamcorper urna. Praesent auctor dui vitae dapibus eleifend. Proin viverra mollis neque, ut ullamcorper elit posuere eget.',
  },
  {
    id: '20230005',
    name: 'Andy',
    age: 32,
    academy: 'Academy D',
    like: 0,
    desc: 'Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed erat diam, blandit eget felis aliquam, rhoncus varius urna. Donec tellus sapien, sodales eget ante vitae, feugiat ullamcorper urna. Praesent auctor dui vitae dapibus eleifend. Proin viverra mollis neque, ut ullamcorper elit posuere eget.',
  },
];

function Teachers() {
  const [data, setData] = useState([]);

  useEffect(() => {
    setData(mockData);
  }, []);

  const handleClikeLike = useCallback(
    (index) => {
      const newData = [...data];
      newData[index].like += 1;
      setData(newData);
    },
    [data]
  );

  return (
    <>
      <Header />
      <main className="main">
        <div className="teachers-list">
          {data.map((item, index) => {
            const { id, name, age, academy, like, desc } = item;
            return (
              <div className="teachers-item" key={id}>
                <div className="line">Name: {name}</div>
                <div className="line">Age: {age}</div>
                <div className="line">Academy: {academy}</div>
                <div className="line like">
                  Like: {like}
                  <button onClick={() => handleClikeLike(index)}>Like</button>
                </div>
                <p className="line desc">{desc}</p>
              </div>
            );
          })}
        </div>
      </main>
    </>
  );
}

export default Teachers;
