import React, { useState } from 'react';
import Header from '../components/Header';
import baseData from './data';
import './HomePage.css';

let AllData = baseData;
const pageSize = 5;

function HomePage() {
  const [data, setData] = useState(AllData);
  const [pageNum, setPageNum] = useState(1);
  const [isEdit, setIsEdit] = useState(false);
  const [editItem, setEditItem] = useState({});

  const doFilterData = () => {
    const select = document.getElementById('select').value;
    const name = document.getElementById('name').value;

    setData(
      AllData.filter((item) => {
        if (select) {
          if (item.gender !== select) return false;
        }

        if (name) {
          if (!item.name.includes(name)) return false;
        }

        return true;
      })
    );
  };

  const handleDelete = (id) => {
    AllData = AllData.filter((item) => item.id !== id);
    doFilterData();
  };

  const handleEdit = (item) => {
    setIsEdit(true);
    setEditItem(item);
  };

  const handleSave = (item) => {
    const idNumber = document.getElementById('idNumber').value;
    const gender = document.getElementById('gender').value;
    const password = document.getElementById('password').value;
    const age = document.getElementById('age').value;
    const academy = document.getElementById('academy').value;

    AllData = AllData.map((i) => {
      if (i.id === item.id) {
        return {
          ...i,
          idNumber,
          gender,
          password,
          age,
          academy,
        };
      }
      return i;
    });
    doFilterData();

    setIsEdit(false);
    setEditItem({});
  };

  return (
    <>
      <Header />
      <main className="main">
        <h3>Teacher management</h3>
        <div className="search">
          <label for="select">Select:</label>
          <select name="select" id="select">
            <option value="">All</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
          <label for="name">Name:</label>
          <input name="name" id="name" placeholder="name"></input>

          <button
            onClick={() => {
              doFilterData();
              setPageNum(1);
            }}
          >
            Search
          </button>
        </div>
        <div className="table">
          <table>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>ID Number</th>
              <th>Gender</th>
              <th>Password</th>
              <th>Age</th>
              <th>Academy</th>
              <th style={{ width: 200 }}>Actions</th>
            </tr>
            {data
              .slice(
                (pageNum - 1) * pageSize,
                (pageNum - 1) * pageSize + pageSize
              )
              .map((item) => {
                const _isEdit = item.id === editItem.id && isEdit;
                return (
                  <tr key={item.id}>
                    <td>{item.id}</td>
                    <td>{item.name}</td>
                    <td>
                      {_isEdit ? (
                        <input id="idNumber" defaultValue={item.idNumber} />
                      ) : (
                        item.idNumber
                      )}
                    </td>
                    <td>
                      {_isEdit ? (
                        <select id="gender" defaultValue={item.gender}>
                          <option value="male">Male</option>
                          <option value="female">Female</option>
                        </select>
                      ) : (
                        item.gender
                      )}
                    </td>
                    <td>
                      {_isEdit ? (
                        <input id="password" defaultValue={item.password} />
                      ) : (
                        item.password
                      )}
                    </td>
                    <td>
                      {_isEdit ? (
                        <input id="age" type="number" defaultValue={item.age} />
                      ) : (
                        item.age
                      )}
                    </td>
                    <td>
                      {_isEdit ? (
                        <input id="academy" defaultValue={item.academy} />
                      ) : (
                        item.academy
                      )}
                    </td>
                    <td className="actions">
                      {!_isEdit ? (
                        <button
                          style={{ marginBottom: 12 }}
                          onClick={() => handleEdit(item)}
                        >
                          Edit
                        </button>
                      ) : (
                        <button
                          style={{ marginBottom: 12 }}
                          onClick={() => handleSave(item)}
                        >
                          Save
                        </button>
                      )}
                      <button onClick={() => handleDelete(item.id)}>
                        Delete
                      </button>
                    </td>
                  </tr>
                );
              })}
          </table>
        </div>
        <div className="footer">
          <div className="meta">
            Total Page: {Math.ceil(data.length / pageSize)}
            &nbsp;&nbsp; Total: {data.length}
          </div>

          <div className="pagination">
            {new Array(Math.ceil(data.length / pageSize))
              .fill(true)
              .map((item, index) => (
                <span
                  key={index}
                  className={index + 1 === pageNum ? 'active' : ''}
                  onClick={() => setPageNum(index + 1)}
                >
                  {index + 1}
                </span>
              ))}
          </div>
        </div>
      </main>
    </>
  );
}

export default HomePage;
