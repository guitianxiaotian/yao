import { useState } from 'react';
import Header from '../components/Header';
import useMessageBoards from '../hooks/useMessageBoards';

import './MessageBoards.css';

function MessageBoards() {
  const [messages, { addMessage, removeMessge }] = useMessageBoards();

  const [value, onChange] = useState();

  const handleSubmit = () => {
    if (value) {
      addMessage({
        content: value,
        date: new Date().toLocaleDateString(),
      });
    }
  };

  return (
    <>
      <Header />
      <main className="main message-boards">
        <div className="message-list">
          {messages.map((message, index) => {
            return (
              <div className="message-item">
                <div>
                  created at:{message.date}
                  <span
                    style={{
                      color: 'red',
                      marginLeft: 12,
                      padding: 2,
                      cursor: 'pointer',
                      border: '1px solid red',
                    }}
                    onClick={() => removeMessge(index)}
                  >
                    DELETE
                  </span>
                </div>
                <div style={{ marginTop: 24 }}>{message.content}</div>
              </div>
            );
          })}
          {messages.length === 0 ? 'Empty' : ''}
        </div>

        <div className="add-message">
          <textarea
            style={{ width: 380, fontSize: 14 }}
            rows={6}
            id="message"
            value={value}
            onChange={(e) => {
              onChange(e.target.value);
            }}
            placeholder="Please enter a message"
          />
          <br />
          <br />
          <button onClick={handleSubmit}>Add message</button>
        </div>
      </main>
    </>
  );
}

export default MessageBoards;
