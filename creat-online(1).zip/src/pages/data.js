
const data=  [
    { id: '20222', name: 'TeacherA', idNumber: '123412341234', gender: 'female', password: '000000', age: 21, academy: 'academyA' },
    { id: '20223', name: 'TeacherB', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20224', name: 'TeacherC', idNumber: '123412341234', gender: 'female', password: '000000', age: 21, academy: 'academyA' },
    { id: '20225', name: 'TeacherD', idNumber: '123412341234', gender: 'female', password: '000000', age: 21, academy: 'academyA' },
    { id: '20226', name: 'TeacherEE', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20227', name: 'TeacherFF', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20228', name: 'TeacherGG', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20229', name: 'TeacherH', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20210', name: 'TeacherE', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20211', name: 'TeacherD', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20212', name: 'TeacherA', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20213', name: 'TeacherE', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20214', name: 'TeacherA', idNumber: '123412341234', gender: 'female', password: '000000', age: 21, academy: 'academyA' },
    { id: '20215', name: 'TeacherA', idNumber: '123412341234', gender: 'female', password: '000000', age: 21, academy: 'academyA' },
    { id: '20216', name: 'TeacherA', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20217', name: 'TeacherA', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20218', name: 'TeacherA', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
    { id: '20219', name: 'TeacherA', idNumber: '123412341234', gender: 'male', password: '000000', age: 21, academy: 'academyA' },
]

export default data;