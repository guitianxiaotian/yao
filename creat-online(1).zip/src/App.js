import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

import HomePage from './pages/HomePage';
import Teachers from './pages/Teachers';
import LoginPage from './pages/Login';
import MessageBoards from './pages/MessageBoards';

import './App.css';

function App() {
  return (
    <div className="app">
      <BrowserRouter>
        <Routes>
          <Route path="/" exact element={<LoginPage />} />
          <Route path="/home" exact element={<HomePage />} />
          <Route path="/teachers" exact element={<Teachers />} />
          <Route path="/message-boards" exact element={<MessageBoards />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
