import { useState, useEffect, useCallback } from 'react';

// Manage messages from localstorage
const storageKey = 'message-boards';
function useMessageBoards() {
  const [messages, setMessges] = useState([]);

  useEffect(() => {
    const data = localStorage.getItem(storageKey);
    if (data) {
      setMessges(JSON.parse(data));
    }
  }, []);

  const updateMessage = useCallback(
    (newMessages) => {
      setMessges(newMessages);
      localStorage.setItem(storageKey, JSON.stringify(newMessages));
    },
    [setMessges]
  );

  const addMessage = (message) => {
    const newMessages = [...messages, message];
    updateMessage(newMessages);
  };

  const removeMessge = (removeIndex) => {
    const newMessages = [...messages];
    newMessages.splice(removeIndex, 1);
    updateMessage(newMessages);
  };

  return [messages, { addMessage, removeMessge }];
}

export default useMessageBoards;
